/*

#pragma once

//helper functions 
void setLift(int power);

//driver control functions
void setLiftMotor();

*/