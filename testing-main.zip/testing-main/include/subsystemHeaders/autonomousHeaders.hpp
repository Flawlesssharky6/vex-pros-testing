#pragma once

//different run cases
void autoSkills();

void redLeftCorner();

void redRightCorner();

void blueLeftCorner();

void blueRightCorner();