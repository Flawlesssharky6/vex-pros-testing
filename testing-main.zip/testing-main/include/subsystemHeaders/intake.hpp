#pragma once

//helper function
void setIntake(int left, int right);

//driver control functions
void setIntakeMotors();