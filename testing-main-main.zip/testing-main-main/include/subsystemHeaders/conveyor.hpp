#pragma once

//helper functions
void setConveyor(int power);

//driver controll functions
void setConveyorMotor();

//autonomous functions
void conveyorIntake(int millisec);
void conveyorOuttake(int millisec);
