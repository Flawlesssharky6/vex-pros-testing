#pragma once 

//helper functions
void setLadyBrownMechanism(int power);

//driver functions
void setLadyBrownMotor();
