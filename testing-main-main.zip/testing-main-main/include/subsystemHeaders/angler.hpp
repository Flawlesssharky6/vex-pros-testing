/*

#pragma once

//helper functions
void setAngler(int power);

//driver control functions
void setAnglerMotor();

*/