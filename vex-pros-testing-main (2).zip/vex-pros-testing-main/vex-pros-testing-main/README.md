This is strictly for testing purposes only. The actual program for the robot is in another repository.
